 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include "mb1501.h"

/*
    Main application
*/

// state vars
bool pgmNeeded = true;
bool ldMonitor = false;

int main(void)
{
    SYSTEM_Initialize();
    
    // Do initialization
    InitIO();
    LEDInit();
    timerStart();

    // Enable the Global Interrupts 
    INTERRUPT_GlobalInterruptEnable(); 

    uint8_t swSettings = getSWSettings();

    
    // loop forever
    while(1)
    {
        // go program if needed
        if(pgmNeeded)       {
            ldMonitor = doTableEntry(swSettings);
            pgmNeeded = false;
            delaySec(SLEEP_TIME);
        }
        
        // five second sleep...
        delaySec(SLEEP_TIME);
    }    
}

// From Lock detect ISR
void SetLockFail(void)
{
    if(!ldMonitor)
        return;             // not monitoring LD
    
    ldMonitor = FALSE;      // ignore further interrupts
    pgmNeeded = TRUE;       // indicate programming is needed
}