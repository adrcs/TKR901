//
// perform device dependent I/O
//

#include "system.h"
#include "mb1501.h"

// interrupt handlers
void Rx_LD_ISR(void);           // rx lock detect ISR
void Tx_LD_ISR(void);           // tx lock detect ISR

void InitIO(void)
{
    RX_LD_SetInterruptHandler(&Rx_LD_ISR);
    TX_LD_SetInterruptHandler(&Tx_LD_ISR);
}

uint8_t getSWSettings(void)
{
    uint8_t sw1 = F4_GetValue();          //SW 1: MSB
    uint8_t sw2 = F5_GetValue();   //SW 2
    uint8_t sw3 = F6_GetValue();   //SW 3
    uint8_t sw4 = F7_GetValue();   //SW 4
    uint8_t sw5 = F3_GetValue();   //SW 5
    uint8_t sw6 = F2_GetValue();   //SW 6    
    uint8_t sw7 = F1_GetValue();   //SW 7    
    uint8_t sw8 = F0_GetValue();   //SW 8
    
    int retval = (sw1<<7 | sw2<<6 | sw3<<5 | sw4<<4 | sw5<<3 | sw6<<2 | sw7<<1 | sw8);
    
    return((uint8_t)(retval & 0xff));
}

// set a logical pin value
void setLogGpio(uint8_t logPin, uint8_t state)
{
    switch (logPin)       {
        
    case LOG_TX_CLK:
        if(state)
            TX_CLK_SetHigh();
        else 
            TX_CLK_SetLow();
        break;
        
	case LOG_TX_DATA:
        if(state)
            TX_DATA_SetHigh();
        else 
            TX_DATA_SetLow();
        break;
           
	case LOG_TX_LE:
        if(state)
            TX_LE_SetHigh();
        else 
            TX_LE_SetLow();
        break;
           
	case LOG_RX_CLK:
        if(state)
            RX_CLK_SetHigh();
        else 
            RX_CLK_SetLow();
        break;
           
	case LOG_RX_DATA:
        if(state)
            RX_DATA_SetHigh();
        else 
            RX_DATA_SetLow();
        break;
           
	case LOG_RX_LE:
        if(state)
            RX_LE_SetHigh();
        else 
            RX_LE_SetLow();
        break;
           
    }
}

// this is not necessary as pins are already set up
void setLogGpioDir(uint8_t pin, uint8_t direction)
{
    return;
}

//rx lock detect ISR
void Rx_LD_ISR(void)
{
    uint8_t ldState = RX_LD_GetValue();
    
    if(ldState) {
        SetLEDState(RX_LED, LED_ON);
        return;
    }
   
    // lock failure
    SetLEDState(RX_LED, LED_FLASH);
    SetLockFail();
}

// tx lock detect failure
void Tx_LD_ISR(void)
{
        uint8_t ldState = TX_LD_GetValue();
    
    if(ldState) {
        SetLEDState(TX_LED, LED_ON);
        return;
    }
        
    SetLEDState(TX_LED, LED_FLASH);
    SetLockFail();
}