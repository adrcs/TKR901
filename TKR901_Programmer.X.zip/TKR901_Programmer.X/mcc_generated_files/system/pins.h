/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA0 aliases
#define RX_CLK_TRIS                 TRISAbits.TRISA0
#define RX_CLK_LAT                  LATAbits.LATA0
#define RX_CLK_PORT                 PORTAbits.RA0
#define RX_CLK_WPU                  WPUAbits.WPUA0
#define RX_CLK_OD                   ODCONAbits.ODCA0
#define RX_CLK_ANS                  ANSELAbits.ANSELA0
#define RX_CLK_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define RX_CLK_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define RX_CLK_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define RX_CLK_GetValue()           PORTAbits.RA0
#define RX_CLK_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define RX_CLK_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define RX_CLK_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define RX_CLK_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define RX_CLK_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define RX_CLK_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define RX_CLK_SetAnalogMode()      do { ANSELAbits.ANSELA0 = 1; } while(0)
#define RX_CLK_SetDigitalMode()     do { ANSELAbits.ANSELA0 = 0; } while(0)

// get/set RA1 aliases
#define RX_DATA_TRIS                 TRISAbits.TRISA1
#define RX_DATA_LAT                  LATAbits.LATA1
#define RX_DATA_PORT                 PORTAbits.RA1
#define RX_DATA_WPU                  WPUAbits.WPUA1
#define RX_DATA_OD                   ODCONAbits.ODCA1
#define RX_DATA_ANS                  ANSELAbits.ANSELA1
#define RX_DATA_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define RX_DATA_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define RX_DATA_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define RX_DATA_GetValue()           PORTAbits.RA1
#define RX_DATA_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define RX_DATA_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define RX_DATA_SetPullup()          do { WPUAbits.WPUA1 = 1; } while(0)
#define RX_DATA_ResetPullup()        do { WPUAbits.WPUA1 = 0; } while(0)
#define RX_DATA_SetPushPull()        do { ODCONAbits.ODCA1 = 0; } while(0)
#define RX_DATA_SetOpenDrain()       do { ODCONAbits.ODCA1 = 1; } while(0)
#define RX_DATA_SetAnalogMode()      do { ANSELAbits.ANSELA1 = 1; } while(0)
#define RX_DATA_SetDigitalMode()     do { ANSELAbits.ANSELA1 = 0; } while(0)

// get/set RA2 aliases
#define RX_LE_TRIS                 TRISAbits.TRISA2
#define RX_LE_LAT                  LATAbits.LATA2
#define RX_LE_PORT                 PORTAbits.RA2
#define RX_LE_WPU                  WPUAbits.WPUA2
#define RX_LE_OD                   ODCONAbits.ODCA2
#define RX_LE_ANS                  ANSELAbits.ANSELA2
#define RX_LE_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define RX_LE_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define RX_LE_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define RX_LE_GetValue()           PORTAbits.RA2
#define RX_LE_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define RX_LE_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define RX_LE_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define RX_LE_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define RX_LE_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define RX_LE_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define RX_LE_SetAnalogMode()      do { ANSELAbits.ANSELA2 = 1; } while(0)
#define RX_LE_SetDigitalMode()     do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set RA3 aliases
#define RX_LD_TRIS                 TRISAbits.TRISA3
#define RX_LD_LAT                  LATAbits.LATA3
#define RX_LD_PORT                 PORTAbits.RA3
#define RX_LD_WPU                  WPUAbits.WPUA3
#define RX_LD_OD                   ODCONAbits.ODCA3
#define RX_LD_ANS                  ANSELAbits.ANSELA3
#define RX_LD_SetHigh()            do { LATAbits.LATA3 = 1; } while(0)
#define RX_LD_SetLow()             do { LATAbits.LATA3 = 0; } while(0)
#define RX_LD_Toggle()             do { LATAbits.LATA3 = ~LATAbits.LATA3; } while(0)
#define RX_LD_GetValue()           PORTAbits.RA3
#define RX_LD_SetDigitalInput()    do { TRISAbits.TRISA3 = 1; } while(0)
#define RX_LD_SetDigitalOutput()   do { TRISAbits.TRISA3 = 0; } while(0)
#define RX_LD_SetPullup()          do { WPUAbits.WPUA3 = 1; } while(0)
#define RX_LD_ResetPullup()        do { WPUAbits.WPUA3 = 0; } while(0)
#define RX_LD_SetPushPull()        do { ODCONAbits.ODCA3 = 0; } while(0)
#define RX_LD_SetOpenDrain()       do { ODCONAbits.ODCA3 = 1; } while(0)
#define RX_LD_SetAnalogMode()      do { ANSELAbits.ANSELA3 = 1; } while(0)
#define RX_LD_SetDigitalMode()     do { ANSELAbits.ANSELA3 = 0; } while(0)
#define RA3_SetInterruptHandler  RX_LD_SetInterruptHandler

// get/set RA4 aliases
#define TX_CLK_TRIS                 TRISAbits.TRISA4
#define TX_CLK_LAT                  LATAbits.LATA4
#define TX_CLK_PORT                 PORTAbits.RA4
#define TX_CLK_WPU                  WPUAbits.WPUA4
#define TX_CLK_OD                   ODCONAbits.ODCA4
#define TX_CLK_ANS                  ANSELAbits.ANSELA4
#define TX_CLK_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define TX_CLK_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define TX_CLK_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define TX_CLK_GetValue()           PORTAbits.RA4
#define TX_CLK_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define TX_CLK_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)
#define TX_CLK_SetPullup()          do { WPUAbits.WPUA4 = 1; } while(0)
#define TX_CLK_ResetPullup()        do { WPUAbits.WPUA4 = 0; } while(0)
#define TX_CLK_SetPushPull()        do { ODCONAbits.ODCA4 = 0; } while(0)
#define TX_CLK_SetOpenDrain()       do { ODCONAbits.ODCA4 = 1; } while(0)
#define TX_CLK_SetAnalogMode()      do { ANSELAbits.ANSELA4 = 1; } while(0)
#define TX_CLK_SetDigitalMode()     do { ANSELAbits.ANSELA4 = 0; } while(0)

// get/set RA5 aliases
#define TX_DATA_TRIS                 TRISAbits.TRISA5
#define TX_DATA_LAT                  LATAbits.LATA5
#define TX_DATA_PORT                 PORTAbits.RA5
#define TX_DATA_WPU                  WPUAbits.WPUA5
#define TX_DATA_OD                   ODCONAbits.ODCA5
#define TX_DATA_ANS                  ANSELAbits.ANSELA5
#define TX_DATA_SetHigh()            do { LATAbits.LATA5 = 1; } while(0)
#define TX_DATA_SetLow()             do { LATAbits.LATA5 = 0; } while(0)
#define TX_DATA_Toggle()             do { LATAbits.LATA5 = ~LATAbits.LATA5; } while(0)
#define TX_DATA_GetValue()           PORTAbits.RA5
#define TX_DATA_SetDigitalInput()    do { TRISAbits.TRISA5 = 1; } while(0)
#define TX_DATA_SetDigitalOutput()   do { TRISAbits.TRISA5 = 0; } while(0)
#define TX_DATA_SetPullup()          do { WPUAbits.WPUA5 = 1; } while(0)
#define TX_DATA_ResetPullup()        do { WPUAbits.WPUA5 = 0; } while(0)
#define TX_DATA_SetPushPull()        do { ODCONAbits.ODCA5 = 0; } while(0)
#define TX_DATA_SetOpenDrain()       do { ODCONAbits.ODCA5 = 1; } while(0)
#define TX_DATA_SetAnalogMode()      do { ANSELAbits.ANSELA5 = 1; } while(0)
#define TX_DATA_SetDigitalMode()     do { ANSELAbits.ANSELA5 = 0; } while(0)

// get/set RA6 aliases
#define TX_LE_TRIS                 TRISAbits.TRISA6
#define TX_LE_LAT                  LATAbits.LATA6
#define TX_LE_PORT                 PORTAbits.RA6
#define TX_LE_WPU                  WPUAbits.WPUA6
#define TX_LE_OD                   ODCONAbits.ODCA6
#define TX_LE_ANS                  ANSELAbits.ANSELA6
#define TX_LE_SetHigh()            do { LATAbits.LATA6 = 1; } while(0)
#define TX_LE_SetLow()             do { LATAbits.LATA6 = 0; } while(0)
#define TX_LE_Toggle()             do { LATAbits.LATA6 = ~LATAbits.LATA6; } while(0)
#define TX_LE_GetValue()           PORTAbits.RA6
#define TX_LE_SetDigitalInput()    do { TRISAbits.TRISA6 = 1; } while(0)
#define TX_LE_SetDigitalOutput()   do { TRISAbits.TRISA6 = 0; } while(0)
#define TX_LE_SetPullup()          do { WPUAbits.WPUA6 = 1; } while(0)
#define TX_LE_ResetPullup()        do { WPUAbits.WPUA6 = 0; } while(0)
#define TX_LE_SetPushPull()        do { ODCONAbits.ODCA6 = 0; } while(0)
#define TX_LE_SetOpenDrain()       do { ODCONAbits.ODCA6 = 1; } while(0)
#define TX_LE_SetAnalogMode()      do { ANSELAbits.ANSELA6 = 1; } while(0)
#define TX_LE_SetDigitalMode()     do { ANSELAbits.ANSELA6 = 0; } while(0)

// get/set RA7 aliases
#define TX_LD_TRIS                 TRISAbits.TRISA7
#define TX_LD_LAT                  LATAbits.LATA7
#define TX_LD_PORT                 PORTAbits.RA7
#define TX_LD_WPU                  WPUAbits.WPUA7
#define TX_LD_OD                   ODCONAbits.ODCA7
#define TX_LD_ANS                  ANSELAbits.ANSELA7
#define TX_LD_SetHigh()            do { LATAbits.LATA7 = 1; } while(0)
#define TX_LD_SetLow()             do { LATAbits.LATA7 = 0; } while(0)
#define TX_LD_Toggle()             do { LATAbits.LATA7 = ~LATAbits.LATA7; } while(0)
#define TX_LD_GetValue()           PORTAbits.RA7
#define TX_LD_SetDigitalInput()    do { TRISAbits.TRISA7 = 1; } while(0)
#define TX_LD_SetDigitalOutput()   do { TRISAbits.TRISA7 = 0; } while(0)
#define TX_LD_SetPullup()          do { WPUAbits.WPUA7 = 1; } while(0)
#define TX_LD_ResetPullup()        do { WPUAbits.WPUA7 = 0; } while(0)
#define TX_LD_SetPushPull()        do { ODCONAbits.ODCA7 = 0; } while(0)
#define TX_LD_SetOpenDrain()       do { ODCONAbits.ODCA7 = 1; } while(0)
#define TX_LD_SetAnalogMode()      do { ANSELAbits.ANSELA7 = 1; } while(0)
#define TX_LD_SetDigitalMode()     do { ANSELAbits.ANSELA7 = 0; } while(0)
#define RA7_SetInterruptHandler  TX_LD_SetInterruptHandler

// get/set RB0 aliases
#define RX_LED_TRIS                 TRISBbits.TRISB0
#define RX_LED_LAT                  LATBbits.LATB0
#define RX_LED_PORT                 PORTBbits.RB0
#define RX_LED_WPU                  WPUBbits.WPUB0
#define RX_LED_OD                   ODCONBbits.ODCB0
#define RX_LED_ANS                  ANSELBbits.ANSELB0
#define RX_LED_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define RX_LED_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define RX_LED_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define RX_LED_GetValue()           PORTBbits.RB0
#define RX_LED_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define RX_LED_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define RX_LED_SetPullup()          do { WPUBbits.WPUB0 = 1; } while(0)
#define RX_LED_ResetPullup()        do { WPUBbits.WPUB0 = 0; } while(0)
#define RX_LED_SetPushPull()        do { ODCONBbits.ODCB0 = 0; } while(0)
#define RX_LED_SetOpenDrain()       do { ODCONBbits.ODCB0 = 1; } while(0)
#define RX_LED_SetAnalogMode()      do { ANSELBbits.ANSELB0 = 1; } while(0)
#define RX_LED_SetDigitalMode()     do { ANSELBbits.ANSELB0 = 0; } while(0)

// get/set RB1 aliases
#define TX_LED_TRIS                 TRISBbits.TRISB1
#define TX_LED_LAT                  LATBbits.LATB1
#define TX_LED_PORT                 PORTBbits.RB1
#define TX_LED_WPU                  WPUBbits.WPUB1
#define TX_LED_OD                   ODCONBbits.ODCB1
#define TX_LED_ANS                  ANSELBbits.ANSELB1
#define TX_LED_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define TX_LED_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define TX_LED_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define TX_LED_GetValue()           PORTBbits.RB1
#define TX_LED_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define TX_LED_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define TX_LED_SetPullup()          do { WPUBbits.WPUB1 = 1; } while(0)
#define TX_LED_ResetPullup()        do { WPUBbits.WPUB1 = 0; } while(0)
#define TX_LED_SetPushPull()        do { ODCONBbits.ODCB1 = 0; } while(0)
#define TX_LED_SetOpenDrain()       do { ODCONBbits.ODCB1 = 1; } while(0)
#define TX_LED_SetAnalogMode()      do { ANSELBbits.ANSELB1 = 1; } while(0)
#define TX_LED_SetDigitalMode()     do { ANSELBbits.ANSELB1 = 0; } while(0)

// get/set RC0 aliases
#define F0_TRIS                 TRISCbits.TRISC0
#define F0_LAT                  LATCbits.LATC0
#define F0_PORT                 PORTCbits.RC0
#define F0_WPU                  WPUCbits.WPUC0
#define F0_OD                   ODCONCbits.ODCC0
#define F0_ANS                  ANSELCbits.ANSELC0
#define F0_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define F0_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define F0_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define F0_GetValue()           PORTCbits.RC0
#define F0_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define F0_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define F0_SetPullup()          do { WPUCbits.WPUC0 = 1; } while(0)
#define F0_ResetPullup()        do { WPUCbits.WPUC0 = 0; } while(0)
#define F0_SetPushPull()        do { ODCONCbits.ODCC0 = 0; } while(0)
#define F0_SetOpenDrain()       do { ODCONCbits.ODCC0 = 1; } while(0)
#define F0_SetAnalogMode()      do { ANSELCbits.ANSELC0 = 1; } while(0)
#define F0_SetDigitalMode()     do { ANSELCbits.ANSELC0 = 0; } while(0)

// get/set RC1 aliases
#define F1_TRIS                 TRISCbits.TRISC1
#define F1_LAT                  LATCbits.LATC1
#define F1_PORT                 PORTCbits.RC1
#define F1_WPU                  WPUCbits.WPUC1
#define F1_OD                   ODCONCbits.ODCC1
#define F1_ANS                  ANSELCbits.ANSELC1
#define F1_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define F1_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define F1_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define F1_GetValue()           PORTCbits.RC1
#define F1_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define F1_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)
#define F1_SetPullup()          do { WPUCbits.WPUC1 = 1; } while(0)
#define F1_ResetPullup()        do { WPUCbits.WPUC1 = 0; } while(0)
#define F1_SetPushPull()        do { ODCONCbits.ODCC1 = 0; } while(0)
#define F1_SetOpenDrain()       do { ODCONCbits.ODCC1 = 1; } while(0)
#define F1_SetAnalogMode()      do { ANSELCbits.ANSELC1 = 1; } while(0)
#define F1_SetDigitalMode()     do { ANSELCbits.ANSELC1 = 0; } while(0)

// get/set RC2 aliases
#define F2_TRIS                 TRISCbits.TRISC2
#define F2_LAT                  LATCbits.LATC2
#define F2_PORT                 PORTCbits.RC2
#define F2_WPU                  WPUCbits.WPUC2
#define F2_OD                   ODCONCbits.ODCC2
#define F2_ANS                  ANSELCbits.ANSELC2
#define F2_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define F2_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define F2_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define F2_GetValue()           PORTCbits.RC2
#define F2_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define F2_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define F2_SetPullup()          do { WPUCbits.WPUC2 = 1; } while(0)
#define F2_ResetPullup()        do { WPUCbits.WPUC2 = 0; } while(0)
#define F2_SetPushPull()        do { ODCONCbits.ODCC2 = 0; } while(0)
#define F2_SetOpenDrain()       do { ODCONCbits.ODCC2 = 1; } while(0)
#define F2_SetAnalogMode()      do { ANSELCbits.ANSELC2 = 1; } while(0)
#define F2_SetDigitalMode()     do { ANSELCbits.ANSELC2 = 0; } while(0)

// get/set RC3 aliases
#define F3_TRIS                 TRISCbits.TRISC3
#define F3_LAT                  LATCbits.LATC3
#define F3_PORT                 PORTCbits.RC3
#define F3_WPU                  WPUCbits.WPUC3
#define F3_OD                   ODCONCbits.ODCC3
#define F3_ANS                  ANSELCbits.ANSELC3
#define F3_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define F3_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define F3_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define F3_GetValue()           PORTCbits.RC3
#define F3_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define F3_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define F3_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define F3_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define F3_SetPushPull()        do { ODCONCbits.ODCC3 = 0; } while(0)
#define F3_SetOpenDrain()       do { ODCONCbits.ODCC3 = 1; } while(0)
#define F3_SetAnalogMode()      do { ANSELCbits.ANSELC3 = 1; } while(0)
#define F3_SetDigitalMode()     do { ANSELCbits.ANSELC3 = 0; } while(0)

// get/set RC4 aliases
#define F4_TRIS                 TRISCbits.TRISC4
#define F4_LAT                  LATCbits.LATC4
#define F4_PORT                 PORTCbits.RC4
#define F4_WPU                  WPUCbits.WPUC4
#define F4_OD                   ODCONCbits.ODCC4
#define F4_ANS                  ANSELCbits.ANSELC4
#define F4_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define F4_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define F4_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define F4_GetValue()           PORTCbits.RC4
#define F4_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define F4_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define F4_SetPullup()          do { WPUCbits.WPUC4 = 1; } while(0)
#define F4_ResetPullup()        do { WPUCbits.WPUC4 = 0; } while(0)
#define F4_SetPushPull()        do { ODCONCbits.ODCC4 = 0; } while(0)
#define F4_SetOpenDrain()       do { ODCONCbits.ODCC4 = 1; } while(0)
#define F4_SetAnalogMode()      do { ANSELCbits.ANSELC4 = 1; } while(0)
#define F4_SetDigitalMode()     do { ANSELCbits.ANSELC4 = 0; } while(0)

// get/set RC5 aliases
#define F5_TRIS                 TRISCbits.TRISC5
#define F5_LAT                  LATCbits.LATC5
#define F5_PORT                 PORTCbits.RC5
#define F5_WPU                  WPUCbits.WPUC5
#define F5_OD                   ODCONCbits.ODCC5
#define F5_ANS                  ANSELCbits.ANSELC5
#define F5_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define F5_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define F5_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define F5_GetValue()           PORTCbits.RC5
#define F5_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define F5_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define F5_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define F5_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define F5_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define F5_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define F5_SetAnalogMode()      do { ANSELCbits.ANSELC5 = 1; } while(0)
#define F5_SetDigitalMode()     do { ANSELCbits.ANSELC5 = 0; } while(0)

// get/set RC6 aliases
#define F6_TRIS                 TRISCbits.TRISC6
#define F6_LAT                  LATCbits.LATC6
#define F6_PORT                 PORTCbits.RC6
#define F6_WPU                  WPUCbits.WPUC6
#define F6_OD                   ODCONCbits.ODCC6
#define F6_ANS                  ANSELCbits.ANSELC6
#define F6_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define F6_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define F6_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define F6_GetValue()           PORTCbits.RC6
#define F6_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define F6_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)
#define F6_SetPullup()          do { WPUCbits.WPUC6 = 1; } while(0)
#define F6_ResetPullup()        do { WPUCbits.WPUC6 = 0; } while(0)
#define F6_SetPushPull()        do { ODCONCbits.ODCC6 = 0; } while(0)
#define F6_SetOpenDrain()       do { ODCONCbits.ODCC6 = 1; } while(0)
#define F6_SetAnalogMode()      do { ANSELCbits.ANSELC6 = 1; } while(0)
#define F6_SetDigitalMode()     do { ANSELCbits.ANSELC6 = 0; } while(0)

// get/set RC7 aliases
#define F7_TRIS                 TRISCbits.TRISC7
#define F7_LAT                  LATCbits.LATC7
#define F7_PORT                 PORTCbits.RC7
#define F7_WPU                  WPUCbits.WPUC7
#define F7_OD                   ODCONCbits.ODCC7
#define F7_ANS                  ANSELCbits.ANSELC7
#define F7_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define F7_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define F7_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define F7_GetValue()           PORTCbits.RC7
#define F7_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define F7_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define F7_SetPullup()          do { WPUCbits.WPUC7 = 1; } while(0)
#define F7_ResetPullup()        do { WPUCbits.WPUC7 = 0; } while(0)
#define F7_SetPushPull()        do { ODCONCbits.ODCC7 = 0; } while(0)
#define F7_SetOpenDrain()       do { ODCONCbits.ODCC7 = 1; } while(0)
#define F7_SetAnalogMode()      do { ANSELCbits.ANSELC7 = 1; } while(0)
#define F7_SetDigitalMode()     do { ANSELCbits.ANSELC7 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handler for the RX_LD pin functionality
 * @param none
 * @return none
 */
void RX_LD_ISR(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for RX_LD pin interrupt-on-change functionality.
 *        Allows selecting an interrupt handler for RX_LD at application runtime
 * @pre Pins intializer called
 * @param InterruptHandler function pointer.
 * @return none
 */
void RX_LD_SetInterruptHandler(void (* InterruptHandler)(void));

/**
 * @ingroup  pinsdriver
 * @brief Dynamic Interrupt Handler for RX_LD pin.
 *        This is a dynamic interrupt handler to be used together with the RX_LD_SetInterruptHandler() method.
 *        This handler is called every time the RX_LD ISR is executed and allows any function to be registered at runtime.
 * @pre Pins intializer called
 * @param none
 * @return none
 */
extern void (*RX_LD_InterruptHandler)(void);

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for RX_LD pin. 
 *        This is a predefined interrupt handler to be used together with the RX_LD_SetInterruptHandler() method.
 *        This handler is called every time the RX_LD ISR is executed. 
 * @pre Pins intializer called
 * @param none
 * @return none
 */
void RX_LD_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handler for the TX_LD pin functionality
 * @param none
 * @return none
 */
void TX_LD_ISR(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for TX_LD pin interrupt-on-change functionality.
 *        Allows selecting an interrupt handler for TX_LD at application runtime
 * @pre Pins intializer called
 * @param InterruptHandler function pointer.
 * @return none
 */
void TX_LD_SetInterruptHandler(void (* InterruptHandler)(void));

/**
 * @ingroup  pinsdriver
 * @brief Dynamic Interrupt Handler for TX_LD pin.
 *        This is a dynamic interrupt handler to be used together with the TX_LD_SetInterruptHandler() method.
 *        This handler is called every time the TX_LD ISR is executed and allows any function to be registered at runtime.
 * @pre Pins intializer called
 * @param none
 * @return none
 */
extern void (*TX_LD_InterruptHandler)(void);

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for TX_LD pin. 
 *        This is a predefined interrupt handler to be used together with the TX_LD_SetInterruptHandler() method.
 *        This handler is called every time the TX_LD ISR is executed. 
 * @pre Pins intializer called
 * @param none
 * @return none
 */
void TX_LD_DefaultInterruptHandler(void);


#endif // PINS_H
/**
 End of File
*/