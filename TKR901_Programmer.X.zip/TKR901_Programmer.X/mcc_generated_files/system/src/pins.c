/**
 * Generated Driver File
 * 
 * @file pins.c
 * 
 * @ingroup  pinsdriver
 * 
 * @brief This is generated driver implementation for pins. 
 *        This file provides implementations for pin APIs for all pins selected in the GUI.
 *
 * @version Driver Version 3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#include "../pins.h"

void (*RX_LD_InterruptHandler)(void);
void (*TX_LD_InterruptHandler)(void);

void PIN_MANAGER_Initialize(void)
{
   /**
    LATx registers
    */
    LATA = 0x0;
    LATB = 0x0;
    LATC = 0x0;
    /**
    ODx registers
    */
    ODCONA = 0x0;
    ODCONB = 0x0;
    ODCONC = 0x0;

    /**
    TRISx registers
    */
    TRISA = 0x88;
    TRISB = 0xFC;
    TRISC = 0xFF;

    /**
    ANSELx registers
    */
    ANSELA = 0x0;
    ANSELB = 0xFC;
    ANSELC = 0x0;

    /**
    WPUx registers
    */
    WPUA = 0x0;
    WPUB = 0x0;
    WPUC = 0x0;
    WPUE = 0x0;


    /**
    SLRCONx registers
    */
    SLRCONA = 0xFF;
    SLRCONB = 0xFF;
    SLRCONC = 0xFF;

    /**
    INLVLx registers
    */
    INLVLA = 0xFF;
    INLVLB = 0xFF;
    INLVLC = 0xFF;
    INLVLE = 0x8;

   /**
    RxyI2C | RxyFEAT registers   
    */
    /**
    PPS registers
    */

   /**
    IOCx registers 
    */
    IOCAP = 0x88;
    IOCAN = 0x88;
    IOCAF = 0x0;
    IOCBP = 0x0;
    IOCBN = 0x0;
    IOCBF = 0x0;
    IOCCP = 0x0;
    IOCCN = 0x0;
    IOCCF = 0x0;
    IOCEP = 0x0;
    IOCEN = 0x0;
    IOCEF = 0x0;

    RX_LD_SetInterruptHandler(RX_LD_DefaultInterruptHandler);
    TX_LD_SetInterruptHandler(TX_LD_DefaultInterruptHandler);

    // Enable PIE0bits.IOCIE interrupt 
    PIE0bits.IOCIE = 1; 
}
  
void PIN_MANAGER_IOC(void)
{
    // interrupt on change for pin RX_LD
    if(IOCAFbits.IOCAF3 == 1)
    {
        RX_LD_ISR();  
    }
    // interrupt on change for pin TX_LD
    if(IOCAFbits.IOCAF7 == 1)
    {
        TX_LD_ISR();  
    }
}
   
/**
   RX_LD Interrupt Service Routine
*/
void RX_LD_ISR(void) {

    // Add custom RX_LD code

    // Call the interrupt handler for the callback registered at runtime
    if(RX_LD_InterruptHandler)
    {
        RX_LD_InterruptHandler();
    }
    IOCAFbits.IOCAF3 = 0;
}

/**
  Allows selecting an interrupt handler for RX_LD at application runtime
*/
void RX_LD_SetInterruptHandler(void (* InterruptHandler)(void)){
    RX_LD_InterruptHandler = InterruptHandler;
}

/**
  Default interrupt handler for RX_LD
*/
void RX_LD_DefaultInterruptHandler(void){
    // add your RX_LD interrupt custom code
    // or set custom function using RX_LD_SetInterruptHandler()
}
   
/**
   TX_LD Interrupt Service Routine
*/
void TX_LD_ISR(void) {

    // Add custom TX_LD code

    // Call the interrupt handler for the callback registered at runtime
    if(TX_LD_InterruptHandler)
    {
        TX_LD_InterruptHandler();
    }
    IOCAFbits.IOCAF7 = 0;
}

/**
  Allows selecting an interrupt handler for TX_LD at application runtime
*/
void TX_LD_SetInterruptHandler(void (* InterruptHandler)(void)){
    TX_LD_InterruptHandler = InterruptHandler;
}

/**
  Default interrupt handler for TX_LD
*/
void TX_LD_DefaultInterruptHandler(void){
    // add your TX_LD interrupt custom code
    // or set custom function using TX_LD_SetInterruptHandler()
}
/**
 End of File
*/