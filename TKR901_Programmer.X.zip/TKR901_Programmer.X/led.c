/*---------------------------------------------------------------------------
	Project:	      PUTSI WiFi

	File Name:	      comLED.c

	Author:		      Martin C. Alcock, VE6VH

	Revision:	      0.02

	Description:      Header file for PUTSI project

                      This software module and all others are the exclusive property of the Alberta Digital 
                      Radio Communications Society and others (?the owners?), all rights are reserved.

                      The owners grant licence to any Amateur for personal or club use, and only on hardware
                      designed by them expressly for this purpose, use on any other hardware is prohibited.
 
                      This file, and others may be copied or distributed only with the inclusion of this 
                      notice.

                      No warranty, either express or implied or transfer of rights is granted in this 
                      licence and the owner is not liable for any outcome whatsoever arising from such usage.

                      Copyright � 2023, Alberta Digital Radio Communications Society


	Revision History:

---------------------------------------------------------------------------*/
#include "system.h"
#include "mb1501.h"

uint8_t txLEDState, txLEDMode;
uint8_t rxLEDState, rxLEDMode;

// internals
void setLEDMode(void);
void LED_SetOff(void);
void LED_TXOn(void);
void LED_TXOff(void);
void LED_RxOn(void);
void LED_RxOff(void);
uint8_t LED_GetTx(void);
uint8_t LED_GetRx(void);

void LEDInit(void)
{
    txLEDState = LED_OFF;
    txLEDMode = NO_TOGGLE;
    
    rxLEDState = LED_OFF;
    rxLEDState = NO_TOGGLE;
    
    LED_SetOff();
}

// set the current state
void SetLEDState(uint8_t led, uint8_t state)
{
    switch (led)  {
        
        case TX_LED:             // both off
            txLEDState = state;
            setLEDMode();
            break;
            
        case RX_LED:             // Wifi Only
            rxLEDState = state;
            setLEDMode();
            break;
    }
}

void setLEDMode(void)
{
    switch(txLEDState)    {

        case LED_OFF:
            LED_TXOff();
            txLEDMode = LED_OFF;
            break;
            
        case LED_ON:
            LED_TXOn();
            txLEDMode = LED_OFF;
            break;
            
        case LED_FLASH:
            LED_TXOn();
            txLEDMode = LED_FLASH;
            break;            
    }
    
      switch(rxLEDState)    {

        case LED_OFF:
            LED_RxOff();
            rxLEDMode = LED_OFF;
            break;
            
        case LED_ON:
            LED_RxOn();
            rxLEDMode = LED_OFF;
            break;
            
        case LED_FLASH:
            LED_RxOn();
            rxLEDMode = LED_FLASH;
            break;            
    }
      
}

// timer interrupt: toggle if in config or thru mode
void Led_timer(void)
{
    uint8_t ledState;
   
    if(txLEDMode == LED_FLASH)      {
        ledState = (LED_GetTx() == LED_ON) ? LED_OFF : LED_ON;
        SetLEDState(TX_LED, ledState);
    }

    if(rxLEDMode == LED_FLASH)      {
        ledState = (LED_GetRx() == LED_ON) ? LED_OFF : LED_ON;
        SetLEDState(RX_LED, ledState);
    }
}

// do the actual updates
void LED_SetOff(void)
{
    RX_LED_SetLow();
    TX_LED_SetLow();
}

// set fwd direction for bidir LED
// set single LED on
void LED_TXOn(void)
{
     TX_LED_SetHigh();
}

void LED_TXOff(void)
{
     TX_LED_SetLow();
}

// set single LED on
void LED_RxOn(void)
{
    RX_LED_SetHigh();
}

// set single LED on
void LED_RxOff(void)
{
    RX_LED_SetLow();
}

uint8_t LED_GetRx(void)
{
    return RX_LED_GetValue();
}

uint8_t LED_GetTx(void)
{
    return TX_LED_GetValue();
}

